from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response

from chatbot.rag.retriever import search_products
from chatbot.rag.prompt import build_prompt
from chatbot.rag.llm import ask_llm
from products.models import Product
from orders.models import Order  
from .agent.executor import run_admin_agent

# RAG CHAT
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def chat(request):
    try:
        question = request.data.get("message", "").strip().lower()
        if not question:
            return Response({"answer": "Bạn chưa nhập câu hỏi nào cả ^^"}, status=200)

        order_keywords = ["đơn hàng", "vận chuyển", "trạng thái", "giao hàng"]
        is_order_query = any(kw in question for kw in order_keywords)

        if is_order_query:
            latest_order = Order.objects.filter(user=request.user).order_by('-created_at').first()
            
            if latest_order:
                status_vi = latest_order.get_status_display() 
                date_str = latest_order.created_at.strftime('%d/%m/%Y lúc %H:%M:%S')
                
                # Tạo prompt
                order_info = f"Đơn hàng mã {latest_order.id} đặt ngày {date_str}, trạng thái hiện tại: {status_vi}."
                prompt = f"Bạn là nhân viên CSKH. Khách hỏi: '{question}'. Thông tin hệ thống báo về: {order_info}. Hãy trả lời khách thật lịch sự."
                
                answer = ask_llm(prompt)
                return Response({"answer": answer})
            else:
                return Response({"answer": "Mình không tìm thấy đơn hàng nào của bạn trong hệ thống. Bạn kiểm tra lại tài khoản nhé!"})

        # (Dành cho hỏi đáp sản phẩm)
        contexts = search_products(question) 
        total_count = Product.objects.count() 
        store_info = f"Tổng số sản phẩm cửa hàng đang có: {total_count}"

        prompt = build_prompt(contexts, question, info=store_info)
        answer = ask_llm(prompt)

        return Response({"answer": answer})

    except Exception as e:
        print(f"LỖI SERVER: {str(e)}") 
        return Response({"answer": "Hệ thống đang bảo trì một chút, bạn thử lại sau nhé!"}, status=500)
    
# AGENT (ADMIN)
@api_view(["POST"])
@permission_classes([IsAdminUser])
def admin_chat(request):
    try:
        question = request.data.get("message")
        if not question:
            return Response({"answer": "Thiếu message"}, status=400)
            
        answer = run_admin_agent(question)
        return Response({"answer": answer}) 
        
    except Exception as e:
        return Response({"answer": f"Lỗi View: {str(e)}"}, status=500)